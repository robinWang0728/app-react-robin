- [Github repository](https://github.com/yoyota/use-user-media)

## Installation

```bash
npm install --save use-user-media
```

## Usage

[useUserMedia](/#/useUserMedia)  
[useUserMediaVideo](/#/useUserMediaVideo)
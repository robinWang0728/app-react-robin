/* Reducers are simple functions which take State and Actions,
   and returns new State. 
*/
export default (state = [], action = {}) => {
  return state;
}
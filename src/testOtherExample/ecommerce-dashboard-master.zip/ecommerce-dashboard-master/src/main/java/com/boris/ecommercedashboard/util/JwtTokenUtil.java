package com.boris.ecommercedashboard.util;

import java.io.Serializable;

public class JwtTokenUtil implements Serializable {

}

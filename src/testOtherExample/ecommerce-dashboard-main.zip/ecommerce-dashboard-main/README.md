# Video tutorial

    https://youtu.be/o6XK4L1z5zI

# Reference

    - Create react app: https://create-react-app.dev/
    - SASS: https://sass-lang.com/
    - Boxicons: https://boxicons.com/
    - Figma: https://www.figma.com/
    - Google font: https://fonts.google.com/

# Preview

!["React Admin Dashboard Template"](https://user-images.githubusercontent.com/67447840/149510678-cd360920-e599-4520-a2f2-590e455e35f7.gif "React Admin Dashboard Template")

!["React Admin Dashboard Template"](https://user-images.githubusercontent.com/67447840/149510750-feb7bb6b-16ae-4b0a-92ca-72dc264c5be1.jpg "React Admin Dashboard Template")
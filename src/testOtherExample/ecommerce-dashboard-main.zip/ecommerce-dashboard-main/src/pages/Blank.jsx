import React from 'react'

const Blank = () => {
    return (
        <div>
            This is a blank page
        </div>
    )
}

export default Blank

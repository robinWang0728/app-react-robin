export { default as images } from './images'
export { default as data } from './data'
export { default as colors } from './colors'
module.exports = {
  env: { browser: 1 },
  extends: 'seegno'
};
